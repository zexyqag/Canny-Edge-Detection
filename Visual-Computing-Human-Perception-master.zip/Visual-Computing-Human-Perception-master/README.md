Visual Computing-Human Perception
